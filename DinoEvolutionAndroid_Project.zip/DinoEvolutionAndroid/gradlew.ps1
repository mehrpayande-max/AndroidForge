param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$GradleArgs
)
$ErrorActionPreference = 'Stop'
$Version = '8.7'
$Base = Join-Path $env:USERPROFILE '.gradle\dino-wrapper'
$Dist = Join-Path $Base "gradle-$Version"
$Gradle = Join-Path $Dist 'bin\gradle.bat'
if (-not (Test-Path $Gradle)) {
    New-Item -ItemType Directory -Force -Path $Base | Out-Null
    $Archive = Join-Path $Base "gradle-$Version-bin.zip"
    Write-Host "Downloading Gradle $Version ..."
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$Version-bin.zip" -OutFile $Archive
    Expand-Archive -Path $Archive -DestinationPath $Base -Force
}
& $Gradle @GradleArgs
exit $LASTEXITCODE
